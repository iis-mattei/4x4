#if !defined (__arc__)
#error These examples only work with onboard SPI flash on Arduino/Genuino 101 board
#endif
#include "SerialFlash.h"
